function convertTemperature() {
    const temp = parseFloat(document.getElementById('temperatureInput').value);
    const fromUnit = document.getElementById('fromUnit').value;
    const toUnit = document.getElementById('toUnit').value;

    if (isNaN(temp)) {
        document.getElementById('result').innerText = "Please enter a valid temperature.";
        return;
    }

    let convertedTemp;

    if (fromUnit === toUnit) {
        convertedTemp = temp;
    } else if (fromUnit === 'Celsius') {
        if (toUnit === 'Fahrenheit') {
            convertedTemp = (temp * 9/5) + 32;
        } else if (toUnit === 'Kelvin') {
            convertedTemp = temp + 273.15;
        }
    } else if (fromUnit === 'Fahrenheit') {
        if (toUnit === 'Celsius') {
            convertedTemp = (temp - 32) * 5/9;
        } else if (toUnit === 'Kelvin') {
            convertedTemp = (temp - 32) * 5/9 + 273.15;
        }
    } else if (fromUnit === 'Kelvin') {
        if (toUnit === 'Celsius') {
            convertedTemp = temp - 273.15;
        } else if (toUnit === 'Fahrenheit') {
            convertedTemp = (temp - 273.15) * 9/5 + 32;
        }
    }

    document.getElementById('result').innerText = `${temp}° ${fromUnit} is ${convertedTemp.toFixed(2)}° ${toUnit}.`;
}
